<script setup>
import DescriptionsDom from '@/components/base/descriptionsDom.vue'

const props = defineProps({
  row: {
    type: Object,
    default: () => ({})
  },
  index: {
    type: Number,
    default: 0
  }
})

const displayIndex = computed(() => String(props.index + 1).padStart(2, '0'))

const getValue = (...keys) => {
  const value = keys.map((key) => props.row?.[key]).find((item) => item !== undefined && item !== null && item !== '')
  return value || '--'
}

const splitLabels = (value) => {
  if (Array.isArray(value)) return value.filter(Boolean)
  if (!value) return []
  return String(value).split(/[,，、\s]+/).filter(Boolean)
}

const labelList = computed(() => {
  const labels = splitLabels(props.row.label_names || props.row.label_name)
  return labels.length > 0 ? labels : []
})

const tagList = computed(() => [
  { label: getValue('company_status_name', 'company_status_text', 'status_name', 'status'), type: 'success' },
  { label: `许可信息 ${getValue('license_count', 'licence_count', 'permit_count', 'permission_count')}`, type: 'info' },
  { label: `网络载体 ${getValue('website_count', 'carrier_count', 'network_count', 'website_total')}`, type: 'warning' },
  { label: `投诉举报 ${getValue('complaint_count', 'report_count', 'complaint_total')}`, type: 'danger' },
  { label: `列严列异 ${getValue('abnormal_count', 'exception_count', 'risk_exception_count')}`, type: 'primary' },
  { label: `双随机 ${getValue('random_count', 'double_random_count')}`, type: 'warning' },
  { label: `行政处罚 ${getValue('punish_count', 'punishment_count', 'administrative_penalty_count')}`, type: 'primary' }
])

const descriptionList = computed(() => [
  {
    label: '统一信用代码',
    prop: 'credit_code',
    formatter: () => getValue('credit_code')
  },
  {
    label: '注册资本',
    prop: 'capital',
    formatter: () => getValue('capital')
  },
  {
    label: '法定代表人',
    prop: 'legal_person',
    formatter: () => getValue('legal_person')
  },
  {
    label: '成立日期',
    prop: 'establish_date',
    formatter: () => getValue('establish_date', 'established_at', 'founded_at', 'start_date')
  },
  {
    label: '行业类型',
    prop: 'industry',
    formatter: () => getValue('industry')
  },
  {
    label: '所属地区',
    prop: 'area_name',
    formatter: () => getValue('area_name', 'region_name', 'district_name', 'org_name')
  },
  {
    label: '地址',
    prop: 'company_address',
    span: 3,
    formatter: () => getValue('company_address')
  }
])
</script>

<template>
  <div class="register-body-row">
    <div class="register-body-row__header">
        <div class="register-body-row__title">
      <span class="register-body-row__index">{{ displayIndex }}.</span>
      <span class="register-body-row__name">{{ getValue('company_name', 'name') }}</span>
      <el-tag v-for="tag in tagList" :key="tag.label" class="register-body-row__tag" :type="tag.type" effect="light" size="small">
        {{ tag.label }}
      </el-tag>
    </div>
        <div v-if="labelList.length > 0" class="register-body-row__labels">
      <el-link v-for="label in labelList" :key="label" type="primary" underline="never">
        {{ label }}
      </el-link>
    </div>
    </div>
    <div class="register-body-row__main">
      <div class="register-body-row__info">
        <DescriptionsDom :row="row" :list="descriptionList" :column="3" :border="false" size="small" />
      </div>
      <div class="register-body-row__score">
        <div class="register-body-row__score-item">
          <strong>{{ getValue('credit_level') }}</strong>
          <span>信用分级</span>
        </div>
        <div class="register-body-row__score-item">
          <strong>{{ getValue('risk_level') }}</strong>
          <span>风险评估</span>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.register-body-row {
  width: 100%;
  min-height: 120px;
  padding: 8px 0;
  color: $black-color;
}

.register-body-row__main {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 24px;
}
.register-body-row__header{
  width: 100%;
}
.register-body-row__title {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 28px;
  flex-wrap: wrap;
}

.register-body-row__index {
  font-size: 20px;
  font-style: italic;
  font-weight: 700;
  color: #657796;
}

.register-body-row__name {
  max-width: 320px;
  font-size: 16px;
  font-weight: 600;
  color: $black-dark;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.register-body-row__tag {
  min-width: 78px;
  justify-content: center;
  border: none;
}

.register-body-row__labels {
  display: flex;
  align-items: center;
  gap: 12px;
  margin: 8px 0 12px 42px;
  min-height: 18px;
}

.register-body-row__labels :deep(.el-link) {
  font-size: 12px;
  font-weight: 600;
}

.register-body-row__info {
  flex: 1;
}

.register-body-row__score {
  width: 200px;
  min-height: 90px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  gap: 20px;
  padding-top: 36px;
  flex-shrink: 0;
}

.register-body-row__score-item {
  min-width: 70px;
  text-align: center;
}

.register-body-row__score-item strong {
  display: block;
  font-size: 38px;
  line-height: 1;
  font-weight: 700;
  color: #1f2530;
}

.register-body-row__score-item span {
  display: block;
  margin-top: 14px;
  font-size: 13px;
  color: #515a6e;
}
</style>
