
import { submitItem } from '@/api/index.js'

const optionCache = new Map()

const createCacheKey = (request) => {
  return JSON.stringify({
    url: request?.url,
    method: request?.method || 'get',
    param: request?.param || {}
  })
}

export const normalizeOptions = (data, request = {}) => {
  const labelKey = request.label || 'label'
  const valueKey = request.value || 'value'
  const childrenKey = request.children || 'children'
  return (Array.isArray(data) ? data : []).map((item) => ({
    label: item[labelKey] ?? item.label ?? item.name ?? '',
    value: item[valueKey] ?? item.value ?? item.id ?? '',
    rawValue: item[valueKey] ?? item.value ?? item.id ?? '',
    raw: item,
    children: item[childrenKey] ? normalizeOptions(item[childrenKey], request) : undefined
  }))
}

export const getOptionData = (response = {}, request = {}) => {
  const data = response?.data
  if (Array.isArray(data)) return data

  const keys = Array.from(new Set([request.children, 'children', 'list', 'rows', 'records', 'items', 'data'].filter(Boolean)))
  if (data && typeof data === 'object') {
    const target = keys.map((key) => data[key]).find(Array.isArray)
    if (target) return target
  }

  const target = keys.map((key) => response?.[key]).find(Array.isArray)
  return target || []
}

export function useFieldOptions(fieldRef) {
  const loading = ref(false)
  const list = ref([])

  const loadOptions = async () => {
    const field = fieldRef.value || {}
    const { request } = field

    if (field.options && field.options.length > 0) {
      list.value = normalizeOptions(field.options, request || {})
      return list.value
    }

    if (!request || !request.url) {
      list.value = []
      return list.value
    }

    const cacheKey = createCacheKey(request)
    if (request.cache !== false && optionCache.has(cacheKey)) {
      list.value = optionCache.get(cacheKey)
      return list.value
    }

    loading.value = true
    try {
      const response = await submitItem(request.url, request.method || 'get', request.param || {}, { keepEmptyKeys: request.keepEmptyKeys || [] })
      const options = normalizeOptions(getOptionData(response, request), request)
      list.value = options
      if (request.cache !== false) {
        optionCache.set(cacheKey, options)
      }
      return options
    } finally {
      loading.value = false
    }
  }

  watch(fieldRef, loadOptions, { deep: true, immediate: true })

  return {
    loading,
    list,
    loadOptions
  }
}
