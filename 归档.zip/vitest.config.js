import { defineConfig } from 'vitest/config'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'path'

export default defineConfig({
  plugins: [vue()],
  test: {
    environment: 'jsdom',
    // 匹配测试文件
    include: ['src/**/*.{test,spec}.js'],
    alias: {
      '@': resolve(__dirname, 'src')
    }
  }
})